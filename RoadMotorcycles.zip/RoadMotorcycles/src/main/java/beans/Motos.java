
package beans;

public class Motos {
    private int id;
    private String marca;
    private String modelo;
    private String cilindraje;
    private int disponible;
    private boolean novedad;

    public Motos(int id, String marca, String modelo, String cilindraje, int disponible, boolean novedad) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.cilindraje = cilindraje;
        this.disponible = disponible;
        this.novedad = novedad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(String cilindraje) {
        this.cilindraje = cilindraje;
    }

    public int getDisponible() {
        return disponible;
    }

    public void setDisponible(int disponible) {
        this.disponible = disponible;
    }

    public boolean isNovedad() {
        return novedad;
    }

    public void setNovedad(boolean novedad) {
        this.novedad = novedad;
    }

    @Override //donde guarda la info para imprimir
    public String toString() {
        return "Motos{" + "id=" + id + ", marca=" + marca + ", modelo=" + modelo 
                + ", cilindraje=" + cilindraje + ", disponible=" + disponible + ", novedad=" + novedad + '}';
    }

   
}
