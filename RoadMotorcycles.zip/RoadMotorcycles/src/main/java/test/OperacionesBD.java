package test;

import beans.Motos;
import connection.DBConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class OperacionesBD {

    public static void main(String[] args) throws ClassNotFoundException {
        listarMoto();
    }

    public static void actualizarMoto(int id, String cilindraje) throws ClassNotFoundException {
        DBConnection con = new DBConnection();
        String sql = "UPDATE motos SET cilindraje = '" + cilindraje + "' WHERE id = " + id;

        try {
        Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
    }

    public static void listarMoto() throws ClassNotFoundException {

        DBConnection con = new DBConnection();
        String sql = "SELECT * FROM motos";

        try {
            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt("id");
                String marca = rs.getString("marca");
                String modelo = rs.getString("modelo");
                String cilindraje = rs.getString("cilindraje");
                int disponible = rs.getInt("disponible");
                boolean novedad = rs.getBoolean("novedad");

                Motos moto = new Motos(id, marca, modelo, cilindraje, disponible, novedad);
                System.out.println(moto.toString());//metodo que instancia para imprimir
            }
            st.executeQuery(sql);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
    }
}

