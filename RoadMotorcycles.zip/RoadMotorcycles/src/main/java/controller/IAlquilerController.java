package controller;

public interface IAlquilerController {
	
	public String listarAlquileres(String username);

}
